import { API_URL } from "src/environments/environment";

export const ALL_TODO = `${API_URL}getAll`;
export const SAVE_TODO = `${API_URL}save`;
export const TOGGLE_TODO = `${API_URL}toggle`;
export const DELETE_TODO = `${API_URL}delete`;